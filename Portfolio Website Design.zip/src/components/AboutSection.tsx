import { motion } from 'motion/react';
import { GraduationCap, Award, Code, Users } from 'lucide-react';

export function AboutSection() {
  const education = [
    {
      title: "Higher National Diploma in Software Engineering",
      institution: "NIBM",
      year: "Current",
      type: "diploma"
    },
    {
      title: "Diploma in Software Engineering",
      institution: "NIBM",
      year: "Completed",
      type: "diploma"
    },
    {
      title: "NVQ Level 4 Computer Hardware Technician",
      institution: "Balapitiya Technical College",
      year: "Completed",
      type: "certificate"
    },
    {
      title: "G.C.E A/L and O/L",
      institution: "G/Aluthwala Maha Vidyalaya",
      year: "Completed",
      type: "school"
    }
  ];

  const traits = [
    { icon: Code, title: "Problem Solver", desc: "Quick learner with strong analytical skills" },
    { icon: Users, title: "Team Player", desc: "Collaborative approach to development" },
    { icon: Award, title: "Quality Focused", desc: "Passionate about clean, efficient code" },
    { icon: GraduationCap, title: "Continuous Learner", desc: "Always exploring new technologies" }
  ];

  return (
    <section className="min-h-screen bg-background text-foreground py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-6 bg-gradient-to-r from-foreground via-muted-foreground to-foreground bg-clip-text text-transparent">
            About Me
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Passionate Software Engineer Intern with expertise in frontend development, 
            responsive UI/UX design, web & mobile applications, IoT systems, and database management. 
            I thrive on solving complex problems and creating innovative solutions.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Education Timeline */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl mb-8 text-center lg:text-left">Education Journey</h3>
            <div className="space-y-6">
              {education.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ 
                    scale: 1.02,
                    boxShadow: "0 10px 30px rgba(255,255,255,0.1)"
                  }}
                  className="relative pl-8 pb-6 border-l-2 border-border hover:border-foreground/50 transition-all duration-300"
                >
                  <div className="absolute -left-2 top-0 w-4 h-4 bg-foreground rounded-full animate-pulse" />
                  <div className="bg-gray-900/50 backdrop-blur-sm p-6 rounded-lg border border-gray-800 hover:border-gray-600 transition-all duration-300">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-lg">{item.title}</h4>
                      <span className="text-sm text-gray-400 bg-gray-800 px-2 py-1 rounded">
                        {item.year}
                      </span>
                    </div>
                    <p className="text-gray-400">{item.institution}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Personal Traits */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl mb-8 text-center lg:text-left">Core Strengths</h3>
            <div className="grid gap-6">
              {traits.map((trait, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, rotateY: -15 }}
                  whileInView={{ opacity: 1, rotateY: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 5,
                    boxShadow: "0 15px 35px rgba(255,255,255,0.1)"
                  }}
                  className="bg-gradient-to-r from-gray-900/80 to-gray-800/80 backdrop-blur-sm p-6 rounded-xl border border-gray-700 hover:border-white/30 transition-all duration-300 cursor-pointer"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-white/10 rounded-lg">
                      <trait.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg mb-2">{trait.title}</h4>
                      <p className="text-gray-400 leading-relaxed">{trait.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Floating elements for visual interest */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full"
              animate={{
                x: [0, Math.random() * 50 - 25],
                y: [0, Math.random() * 50 - 25],
                opacity: [0.2, 0.6, 0.2],
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: Math.random() * 4 + 3,
                repeat: Infinity,
                repeatType: "reverse",
              }}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}