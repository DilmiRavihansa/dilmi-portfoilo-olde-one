import { motion } from 'motion/react';
import { ExternalLink, Github } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ProjectsSection() {
  const projects = [
    {
      title: "Dedicated Economic Center Web & Mobile App",
      description: "Full-stack web and mobile application built with React.js, Flutter, Node.js, and MySQL. Features comprehensive economic data management and real-time analytics.",
      tech: ["React.js", "Flutter", "Node.js", "MySQL"],
      image: "https://images.unsplash.com/photo-1565687981296-535f09db714e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3ZWIlMjBkZXZlbG9wbWVudCUyMHJlYWN0JTIwY29kaW5nfGVufDF8fHx8MTc1NzQ0MzEzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "Web & Mobile"
    },
    {
      title: "Smart Pet Feeder System",
      description: "IoT-enabled pet feeding system using Flutter mobile app, Firebase backend, NodeMCU microcontroller, and RTC module for automated feeding schedules.",
      tech: ["IoT", "Flutter", "Firebase", "NodeMCU", "RTC"],
      image: "https://images.unsplash.com/photo-1739764577422-20863c027cb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxpb3QlMjBzbWFydCUyMGRldmljZSUyMGFyZHVpbm98ZW58MXx8fHwxNzU3NDQzMTM3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "IoT"
    },
    {
      title: "Computer Shop Management System",
      description: "Desktop application for computer shop inventory and sales management built with JavaFX frontend, Spring Boot backend, and MySQL database.",
      tech: ["JavaFX", "Spring Boot", "MySQL"],
      image: "https://images.unsplash.com/photo-1756801370266-f589801cedc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxjb21wdXRlciUyMGhhcmR3YXJlJTIwcmVwYWlyJTIwdGVjaG5pY2lhbnxlbnwxfHx8fDE3NTc0NDMxMzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "Desktop"
    },
    {
      title: "Rare Crop Home Agricultural Exchange",
      description: "Web-based marketplace platform for rare crop trading built with HTML, CSS, and PHP. Features user authentication, product listings, and transaction management.",
      tech: ["HTML", "CSS", "PHP", "MySQL"],
      image: "https://images.unsplash.com/photo-1641437741884-ca0289c1490e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBmbHV0dGVyJTIwZGV2ZWxvcG1lbnR8ZW58MXx8fHwxNzU3NDQzMTM3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      category: "Web"
    }
  ];

  return (
    <section className="min-h-screen bg-background text-foreground py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-6 bg-gradient-to-r from-foreground via-muted-foreground to-foreground bg-clip-text text-transparent">
            Featured Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A showcase of diverse projects spanning web development, mobile applications, 
            IoT systems, and desktop software solutions.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, rotateY: -15, y: 50 }}
              whileInView={{ opacity: 1, rotateY: 0, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ 
                scale: 1.03,
                rotateY: 5,
                z: 50
              }}
              className="group relative"
            >
              {/* Project Card */}
              <div className="bg-gradient-to-br from-card/80 to-card/60 backdrop-blur-sm rounded-2xl overflow-hidden border border-border hover:border-foreground/30 transition-all duration-500 h-full">
                {/* Project Image */}
                <div className="relative overflow-hidden h-64">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                    className="w-full h-full"
                  >
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover"
                    />
                  </motion.div>
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-4 left-4 right-4 flex gap-3">
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-2 bg-foreground/20 backdrop-blur-sm rounded-lg hover:bg-foreground/30 transition-all duration-300"
                      >
                        <Github className="w-5 h-5" />
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-2 bg-white/20 backdrop-blur-sm rounded-lg hover:bg-white/30 transition-all duration-300"
                      >
                        <ExternalLink className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-sm">
                      {project.category}
                    </span>
                  </div>
                </div>

                {/* Project Content */}
                <div className="p-6">
                  <h3 className="text-xl mb-3 group-hover:text-white transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-gray-400 mb-4 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((tech, techIndex) => (
                      <motion.span
                        key={techIndex}
                        initial={{ opacity: 0, scale: 0.8 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: techIndex * 0.1 }}
                        viewport={{ once: true }}
                        whileHover={{ scale: 1.1, y: -2 }}
                        className="px-3 py-1 bg-gray-800/50 border border-gray-600 rounded-full text-sm text-gray-300 hover:border-white/50 hover:text-white transition-all duration-300"
                      >
                        {tech}
                      </motion.span>
                    ))}
                  </div>
                </div>

                {/* Floating particles */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
                  {[...Array(3)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1 h-1 bg-white rounded-full opacity-30"
                      animate={{
                        x: [0, Math.random() * 30 - 15],
                        y: [0, Math.random() * 30 - 15],
                        opacity: [0.3, 0.7, 0.3],
                      }}
                      transition={{
                        duration: Math.random() * 3 + 2,
                        repeat: Infinity,
                        repeatType: "reverse",
                      }}
                      style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Glow effect */}
              <motion.div
                className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl -z-10"
                whileHover={{ scale: 1.05 }}
              />
            </motion.div>
          ))}
        </div>

        {/* Background 3D elements */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(10)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-6 h-6 border border-gray-600/10 rounded-lg"
              animate={{
                rotateX: [0, 360],
                rotateY: [0, -360],
                rotateZ: [0, 180],
              }}
              transition={{
                duration: 8 + i,
                repeat: Infinity,
                ease: "linear",
              }}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}