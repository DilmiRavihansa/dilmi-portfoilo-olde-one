import { motion, useScroll, useTransform } from 'motion/react';
import { useState, useEffect } from 'react';
import { Menu, X, Sun, Moon, Zap, Code2, User, Briefcase, Mail, Home } from 'lucide-react';
import { useTheme } from './ThemeProvider';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const { theme, toggleTheme } = useTheme();
  const { scrollY } = useScroll();

  // Transform values for advanced animations
  const navOpacity = useTransform(scrollY, [0, 100], [0.95, 1]);
  const navBlur = useTransform(scrollY, [0, 100], [8, 20]);

  const navItems = [
    { name: 'Home', href: '#home', icon: Home },
    { name: 'About', href: '#about', icon: User },
    { name: 'Skills', href: '#skills', icon: Code2 },
    { name: 'Projects', href: '#projects', icon: Briefcase },
    { name: 'Experience', href: '#experience', icon: Zap },
    { name: 'Contact', href: '#contact', icon: Mail },
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 100;
      setIsScrolled(window.scrollY > 50);

      // Update active section based on scroll position
      const sections = navItems.map(item => item.href.substring(1));
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Main Navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        style={{ 
          backdropFilter: `blur(${navBlur}px)`,
          opacity: navOpacity 
        }}
        className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-white/10 dark:bg-gray-900/10 border border-white/20 dark:border-gray-700/30 shadow-2xl'
            : 'bg-white/5 dark:bg-gray-900/5 border border-white/10 dark:border-gray-700/20'
        } rounded-2xl px-6 py-3`}
      >
        <div className="flex items-center justify-between">
          {/* Logo with advanced effects */}
          <motion.div
            whileHover={{ 
              scale: 1.05,
              rotateY: 5,
            }}
            whileTap={{ scale: 0.98 }}
            className="cursor-pointer relative group"
            onClick={() => scrollToSection('#home')}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-lg blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <h1 className="relative text-xl font-bold bg-gradient-to-r from-blue-600 via-blue-700 to-cyan-600 dark:from-blue-400 dark:via-blue-500 dark:to-cyan-400 bg-clip-text text-transparent">
              SH
            </h1>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-2">
            {navItems.map((item, index) => {
              const isActive = activeSection === item.href.substring(1);
              const Icon = item.icon;
              
              return (
                <motion.button
                  key={item.name}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ 
                    scale: 1.05,
                    y: -2,
                  }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => scrollToSection(item.href)}
                  className={`
                    relative px-4 py-2 rounded-xl transition-all duration-300 group
                    ${isActive 
                      ? 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-blue-600 dark:text-blue-400' 
                      : 'text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400'
                    }
                  `}
                >
                  {/* Background glow effect */}
                  <div className={`
                    absolute inset-0 rounded-xl blur-xl transition-opacity duration-300
                    ${isActive 
                      ? 'bg-gradient-to-r from-blue-500/30 to-cyan-500/30 opacity-100' 
                      : 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 opacity-0 group-hover:opacity-100'
                    }
                  `} />
                  
                  {/* Content */}
                  <div className="relative flex items-center space-x-2">
                    <Icon className="w-4 h-4" />
                    <span className="font-medium">{item.name}</span>
                  </div>

                  {/* Active indicator */}
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </motion.button>
              );
            })}

            {/* Advanced Theme Toggle */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative ml-4"
            >
              <motion.button
                onClick={toggleTheme}
                className="p-3 rounded-xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 hover:from-blue-500/20 hover:to-cyan-500/20 transition-all duration-300 group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <motion.div
                  animate={{ rotate: theme === 'dark' ? 180 : 0 }}
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                  className="relative"
                >
                  {theme === 'dark' ? (
                    <Sun className="w-5 h-5 text-yellow-500" />
                  ) : (
                    <Moon className="w-5 h-5 text-blue-600" />
                  )}
                </motion.div>
              </motion.button>
            </motion.div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-lg bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 text-gray-600 dark:text-gray-300"
            >
              <motion.div
                animate={{ rotate: isMobileMenuOpen ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </motion.div>
            </motion.button>
          </div>
        </div>
      </motion.nav>

      {/* Advanced Mobile Menu */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: -20 }}
        animate={{
          opacity: isMobileMenuOpen ? 1 : 0,
          scale: isMobileMenuOpen ? 1 : 0.95,
          y: isMobileMenuOpen ? 0 : -20,
        }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className={`
          fixed top-20 left-4 right-4 z-40 md:hidden rounded-2xl overflow-hidden
          ${isMobileMenuOpen ? 'pointer-events-auto' : 'pointer-events-none'}
          bg-white/10 dark:bg-gray-900/10 backdrop-blur-2xl border border-white/20 dark:border-gray-700/30 shadow-2xl
        `}
      >
        <div className="p-6 space-y-3">
          {/* Mobile Theme Toggle */}
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ 
              opacity: isMobileMenuOpen ? 1 : 0,
              x: isMobileMenuOpen ? 0 : -20,
            }}
            transition={{ duration: 0.3 }}
            whileHover={{ x: 10, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={toggleTheme}
            className="flex items-center gap-4 w-full p-4 rounded-xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 hover:from-blue-500/20 hover:to-cyan-500/20 transition-all duration-300 group"
          >
            <div className="relative">
              <motion.div
                animate={{ rotate: theme === 'dark' ? 180 : 0 }}
                transition={{ duration: 0.5 }}
              >
                {theme === 'dark' ? (
                  <Sun className="w-6 h-6 text-yellow-500" />
                ) : (
                  <Moon className="w-6 h-6 text-blue-600" />
                )}
              </motion.div>
            </div>
            <span className="font-medium text-gray-700 dark:text-gray-200">
              {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            </span>
          </motion.button>
          
          {/* Mobile Navigation Items */}
          {navItems.map((item, index) => {
            const isActive = activeSection === item.href.substring(1);
            const Icon = item.icon;
            
            return (
              <motion.button
                key={item.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ 
                  opacity: isMobileMenuOpen ? 1 : 0,
                  x: isMobileMenuOpen ? 0 : -20,
                }}
                transition={{ duration: 0.3, delay: (index + 1) * 0.1 }}
                whileHover={{ x: 10, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => scrollToSection(item.href)}
                className={`
                  flex items-center gap-4 w-full p-4 rounded-xl transition-all duration-300 group
                  ${isActive 
                    ? 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-500/30 text-blue-600 dark:text-blue-400' 
                    : 'hover:bg-gradient-to-r hover:from-blue-500/10 hover:to-cyan-500/10 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400'
                  }
                `}
              >
                <Icon className="w-6 h-6" />
                <span className="font-medium">{item.name}</span>
                {isActive && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="ml-auto w-2 h-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"
                  />
                )}
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* Smart Floating Progress Indicator */}
      <motion.div
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 1 }}
        className="fixed right-8 top-1/2 transform -translate-y-1/2 z-40 hidden xl:block"
      >
        <div className="relative">
          {/* Progress track */}
          <div className="w-1 h-48 bg-gray-300/30 dark:bg-gray-600/30 rounded-full overflow-hidden">
            <motion.div
              className="w-full bg-gradient-to-b from-blue-500 to-cyan-500 rounded-full origin-top"
              style={{
                scaleY: useTransform(scrollY, [0, document.body.scrollHeight - window.innerHeight], [0, 1])
              }}
            />
          </div>
          
          {/* Section indicators */}
          <div className="absolute -left-2 top-0 h-full flex flex-col justify-between">
            {navItems.map((item, index) => {
              const isActive = activeSection === item.href.substring(1);
              const Icon = item.icon;
              
              return (
                <motion.button
                  key={item.name}
                  whileHover={{ scale: 1.3, x: -8 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => scrollToSection(item.href)}
                  className={`
                    relative w-5 h-5 rounded-full transition-all duration-300 group flex items-center justify-center
                    ${isActive 
                      ? 'bg-gradient-to-r from-blue-500 to-cyan-500 shadow-lg shadow-blue-500/30' 
                      : 'bg-gray-400/50 dark:bg-gray-600/50 hover:bg-blue-500/70'
                    }
                  `}
                >
                  <Icon className="w-3 h-3 text-white" />
                  
                  {/* Advanced Tooltip */}
                  <motion.div
                    initial={{ opacity: 0, x: 10, scale: 0.8 }}
                    whileHover={{ opacity: 1, x: -10, scale: 1 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-8 px-3 py-2 bg-gray-900/90 dark:bg-white/90 text-white dark:text-gray-900 text-sm rounded-lg whitespace-nowrap backdrop-blur-sm border border-gray-700/50 dark:border-gray-200/50 shadow-xl"
                  >
                    {item.name}
                    <div className="absolute left-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-l-gray-900/90 dark:border-l-white/90" />
                  </motion.div>
                </motion.button>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* Backdrop overlay for mobile menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setIsMobileMenuOpen(false)}
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 md:hidden"
        />
      )}
    </>
  );
}