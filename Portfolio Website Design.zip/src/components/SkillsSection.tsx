import { motion } from 'motion/react';
import { Code, Smartphone, Database, Settings, Github, Figma } from 'lucide-react';

export function SkillsSection() {
  const skillCategories = [
    {
      title: "Frontend/Web",
      icon: Code,
      skills: ["HTML", "CSS", "JavaScript", "React.js", "Tailwind", "Node.js", "Spring Boot"],
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "Programming",
      icon: Settings,
      skills: ["Java", "C++", "Dart", "PHP", "C#", "C"],
      color: "from-green-500 to-emerald-500"
    },
    {
      title: "Mobile",
      icon: Smartphone,
      skills: ["Flutter", "Kotlin"],
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "Databases",
      icon: Database,
      skills: ["MySQL", "MongoDB", "Firebase", "Oracle"],
      color: "from-orange-500 to-red-500"
    },
    {
      title: "Tools",
      icon: Github,
      skills: ["GitHub", "Figma", "Postman", "VS Code", "IntelliJ", "Android Studio", "Arduino"],
      color: "from-gray-500 to-slate-500"
    },
    {
      title: "IoT & ML",
      icon: Figma,
      skills: ["NodeMCU", "Arduino", "Jupyter Notebooks"],
      color: "from-yellow-500 to-amber-500"
    }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-accent/20 via-background to-accent/20 text-foreground py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-6 bg-gradient-to-r from-foreground via-muted-foreground to-foreground bg-clip-text text-transparent">
            Technical Skills
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A comprehensive toolkit spanning frontend development, mobile applications, 
            IoT systems, and database management.
          </p>
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, rotateX: -15, y: 50 }}
              whileInView={{ opacity: 1, rotateX: 0, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ 
                scale: 1.05,
                rotateY: 5,
                z: 50
              }}
              className="relative group"
            >
              {/* Card */}
              <div className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm p-8 rounded-2xl border border-border hover:border-foreground/30 transition-all duration-500 h-full">
                {/* Icon and Title */}
                <div className="flex items-center gap-4 mb-6">
                  <motion.div
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                    className={`p-4 rounded-xl bg-gradient-to-r ${category.color} shadow-lg`}
                  >
                    <category.icon className="w-8 h-8 text-white" />
                  </motion.div>
                  <h3 className="text-2xl">{category.title}</h3>
                </div>

                {/* Skills List */}
                <div className="space-y-3">
                  {category.skills.map((skill, skillIndex) => (
                    <motion.div
                      key={skillIndex}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: skillIndex * 0.1 }}
                      viewport={{ once: true }}
                      whileHover={{ 
                        scale: 1.05,
                        x: 10,
                      }}
                      className="flex items-center gap-3 p-3 bg-accent/30 rounded-lg hover:bg-accent/50 transition-all duration-300 cursor-pointer"
                    >
                      <motion.div
                        className={`w-2 h-2 rounded-full bg-gradient-to-r ${category.color}`}
                        animate={{
                          scale: [1, 1.2, 1],
                          opacity: [0.7, 1, 0.7],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: skillIndex * 0.2,
                        }}
                      />
                      <span className="text-muted-foreground group-hover:text-foreground transition-colors duration-300">
                        {skill}
                      </span>
                    </motion.div>
                  ))}
                </div>

                {/* Floating particles for each card */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      className={`absolute w-1 h-1 rounded-full bg-gradient-to-r ${category.color} opacity-40`}
                      animate={{
                        x: [0, Math.random() * 20 - 10],
                        y: [0, Math.random() * 20 - 10],
                        opacity: [0.4, 0.8, 0.4],
                      }}
                      transition={{
                        duration: Math.random() * 3 + 2,
                        repeat: Infinity,
                        repeatType: "reverse",
                      }}
                      style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Glow effect on hover */}
              <motion.div
                className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-xl -z-10`}
                whileHover={{ scale: 1.1 }}
              />
            </motion.div>
          ))}
        </div>

        {/* Background 3D elements */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute border border-gray-600/20 rounded-lg opacity-10"
              animate={{
                rotateX: [0, 360],
                rotateY: [0, 360],
                rotateZ: [0, 180],
              }}
              transition={{
                duration: 10 + i * 2,
                repeat: Infinity,
                ease: "linear",
              }}
              style={{
                width: `${20 + Math.random() * 40}px`,
                height: `${20 + Math.random() * 40}px`,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}