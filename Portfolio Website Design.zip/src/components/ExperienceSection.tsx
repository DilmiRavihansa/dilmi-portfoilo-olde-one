import { motion } from 'motion/react';
import { Briefcase, Monitor, Wrench, Users, Award } from 'lucide-react';

export function ExperienceSection() {
  const experience = {
    company: "Sarasi Computer House (Pvt) Ltd",
    role: "Computer Hardware Technician",
    responsibilities: [
      "CCTV installation and maintenance",
      "Hardware and software troubleshooting",
      "Computer repair and diagnostics",
      "Customer service and technical support",
      "Sales and product consultation"
    ]
  };

  const softSkills = [
    { icon: Users, title: "Teamwork", desc: "Collaborative problem-solving" },
    { icon: Award, title: "Leadership", desc: "Project management and guidance" },
    { icon: Monitor, title: "Communication", desc: "Clear technical explanations" },
    { icon: Wrench, title: "Problem-Solving", desc: "Analytical and creative solutions" }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-6 bg-gradient-to-r from-white via-gray-300 to-white bg-clip-text text-transparent">
            Experience & Skills
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Practical experience in hardware troubleshooting combined with strong interpersonal 
            and leadership abilities.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Work Experience */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              {/* 3D rotating cube effect */}
              <motion.div
                whileHover={{ rotateY: 180 }}
                transition={{ duration: 0.8 }}
                className="preserve-3d cursor-pointer"
              >
                <div className="relative bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm p-8 rounded-2xl border border-gray-700 hover:border-white/30 transition-all duration-500">
                  {/* Company Header */}
                  <div className="flex items-center gap-4 mb-6">
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className="p-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl"
                    >
                      <Briefcase className="w-8 h-8 text-white" />
                    </motion.div>
                    <div>
                      <h3 className="text-2xl">{experience.company}</h3>
                      <p className="text-gray-400">{experience.role}</p>
                    </div>
                  </div>

                  {/* Responsibilities */}
                  <h4 className="text-lg mb-4">Key Responsibilities:</h4>
                  <div className="space-y-3">
                    {experience.responsibilities.map((responsibility, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        viewport={{ once: true }}
                        whileHover={{ x: 10, scale: 1.02 }}
                        className="flex items-center gap-3 p-3 bg-gray-800/30 rounded-lg hover:bg-gray-700/50 transition-all duration-300"
                      >
                        <motion.div
                          className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500"
                          animate={{
                            scale: [1, 1.3, 1],
                            opacity: [0.7, 1, 0.7],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            delay: index * 0.3,
                          }}
                        />
                        <span className="text-gray-300">{responsibility}</span>
                      </motion.div>
                    ))}
                  </div>

                  {/* Background pattern */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
                    {[...Array(6)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-1 h-1 bg-blue-500/30 rounded-full"
                        animate={{
                          x: [0, Math.random() * 20 - 10],
                          y: [0, Math.random() * 20 - 10],
                          opacity: [0.3, 0.7, 0.3],
                        }}
                        transition={{
                          duration: Math.random() * 3 + 2,
                          repeat: Infinity,
                          repeatType: "reverse",
                        }}
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Soft Skills */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl mb-8 text-center lg:text-left">Soft Skills</h3>
            <div className="space-y-6">
              {softSkills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, rotateX: -15 }}
                  whileInView={{ opacity: 1, rotateX: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 5,
                    boxShadow: "0 20px 40px rgba(255,255,255,0.1)"
                  }}
                  className="group relative"
                >
                  <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 backdrop-blur-sm p-6 rounded-xl border border-gray-700 hover:border-white/30 transition-all duration-500">
                    <div className="flex items-center gap-4">
                      <motion.div
                        whileHover={{ rotate: 360, scale: 1.1 }}
                        transition={{ duration: 0.6 }}
                        className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg shadow-lg"
                      >
                        <skill.icon className="w-6 h-6 text-white" />
                      </motion.div>
                      <div>
                        <h4 className="text-lg mb-1">{skill.title}</h4>
                        <p className="text-gray-400">{skill.desc}</p>
                      </div>
                    </div>

                    {/* Skill level indicator */}
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${85 + Math.random() * 15}%` }}
                      transition={{ duration: 1, delay: index * 0.2 }}
                      viewport={{ once: true }}
                      className="mt-4 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                    />
                  </div>

                  {/* Glow effect */}
                  <motion.div
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl -z-10"
                    whileHover={{ scale: 1.1 }}
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Career Profile Quote */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="max-w-4xl mx-auto p-8 bg-gradient-to-r from-gray-800/30 to-gray-900/30 backdrop-blur-sm rounded-2xl border border-gray-700">
            <motion.blockquote
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.8 }}
              viewport={{ once: true }}
              className="text-xl italic text-gray-300 leading-relaxed"
            >
              "Passionate about frontend development, responsive UI/UX, web & mobile apps, IoT, and database systems. 
              Strong team player, quick learner, and problem-solver dedicated to creating innovative solutions."
            </motion.blockquote>
          </div>
        </motion.div>

        {/* Background 3D elements */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute border border-gray-600/10 rounded-lg opacity-20"
              animate={{
                rotateX: [0, 360],
                rotateY: [0, -360],
              }}
              transition={{
                duration: 12 + i * 2,
                repeat: Infinity,
                ease: "linear",
              }}
              style={{
                width: `${15 + Math.random() * 25}px`,
                height: `${15 + Math.random() * 25}px`,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}